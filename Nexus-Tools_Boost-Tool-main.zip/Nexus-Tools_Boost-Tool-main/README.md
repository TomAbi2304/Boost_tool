# Nexus-Tools_Boost-Tool
A simple boost tool wich won't lock the tokens after the boost. If you skid give credits to Nexus-Tools

#Functions
Joiner
Hcaptcha solver
Booster
Nickname Changer

#SKID
If you skid it would be nice if you give credit to nexus or discord.gg/nexus-tools

Thats all enjoy <3
